g++ -g -o demo demo.cpp src/yolo-fastestv2.cpp -I src/include -I include/ncnn -I /usr/include/opencv4 lib/libncnn.a `pkg-config --libs --cflags opencv4` -fopenmp

